<?php

return [
    'name' => 'Wallet',
];
